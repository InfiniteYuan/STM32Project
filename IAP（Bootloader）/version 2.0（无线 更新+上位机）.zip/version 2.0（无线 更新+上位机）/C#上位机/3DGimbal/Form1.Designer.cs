﻿namespace _3DGimbal
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.timCheckFrame = new System.Windows.Forms.Timer(this.components);
            this.timGetInfo = new System.Windows.Forms.Timer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.leftpanel = new System.Windows.Forms.Panel();
            this.seconddatapanel = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.exitTabPanel = new System.Windows.Forms.Panel();
            this.exitLabelText = new System.Windows.Forms.Label();
            this.updatepanel = new System.Windows.Forms.Panel();
            this.updatelabel = new System.Windows.Forms.Label();
            this.datapanel = new System.Windows.Forms.Panel();
            this.datapictureBox = new System.Windows.Forms.PictureBox();
            this.datalabel = new System.Windows.Forms.Label();
            this.connectTabPanel = new System.Windows.Forms.Panel();
            this.connectPicBox = new System.Windows.Forms.PictureBox();
            this.connectLabelText = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tbMotorVel = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnSetVelocity = new System.Windows.Forms.Button();
            this.tkMotorVel = new System.Windows.Forms.TrackBar();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.button11 = new System.Windows.Forms.Button();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.leftpanel.SuspendLayout();
            this.seconddatapanel.SuspendLayout();
            this.exitTabPanel.SuspendLayout();
            this.updatepanel.SuspendLayout();
            this.datapanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datapictureBox)).BeginInit();
            this.connectTabPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.connectPicBox)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel5.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tkMotorVel)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // timCheckFrame
            // 
            this.timCheckFrame.Enabled = true;
            this.timCheckFrame.Interval = 10;
            this.timCheckFrame.Tick += new System.EventHandler(this.timCheckFrame_Tick);
            // 
            // timGetInfo
            // 
            this.timGetInfo.Enabled = true;
            this.timGetInfo.Interval = 15;
            this.timGetInfo.Tick += new System.EventHandler(this.timGetInfo_Tick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SlateBlue;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 70);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(55, 50);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.SlateBlue;
            this.label4.Font = new System.Drawing.Font("华文彩云", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(85, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 24);
            this.label4.TabIndex = 0;
            this.label4.Text = "固件更新";
            // 
            // leftpanel
            // 
            this.leftpanel.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.leftpanel.Controls.Add(this.seconddatapanel);
            this.leftpanel.Controls.Add(this.exitTabPanel);
            this.leftpanel.Controls.Add(this.updatepanel);
            this.leftpanel.Controls.Add(this.datapanel);
            this.leftpanel.Controls.Add(this.connectTabPanel);
            this.leftpanel.Controls.Add(this.panel2);
            this.leftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftpanel.Location = new System.Drawing.Point(0, 0);
            this.leftpanel.Name = "leftpanel";
            this.leftpanel.Size = new System.Drawing.Size(250, 600);
            this.leftpanel.TabIndex = 0;
            // 
            // seconddatapanel
            // 
            this.seconddatapanel.Controls.Add(this.label15);
            this.seconddatapanel.Controls.Add(this.label14);
            this.seconddatapanel.Location = new System.Drawing.Point(0, 352);
            this.seconddatapanel.Name = "seconddatapanel";
            this.seconddatapanel.Size = new System.Drawing.Size(250, 50);
            this.seconddatapanel.TabIndex = 66;
            // 
            // label15
            // 
            this.label15.Dock = System.Windows.Forms.DockStyle.Top;
            this.label15.Font = new System.Drawing.Font("华文行楷", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(0, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(250, 23);
            this.label15.TabIndex = 1;
            this.label15.Text = "  参数设置";
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("华文行楷", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(250, 25);
            this.label14.TabIndex = 0;
            this.label14.Text = "  参数设置";
            // 
            // exitTabPanel
            // 
            this.exitTabPanel.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.exitTabPanel.Controls.Add(this.exitLabelText);
            this.exitTabPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.exitTabPanel.Location = new System.Drawing.Point(0, 220);
            this.exitTabPanel.Margin = new System.Windows.Forms.Padding(4);
            this.exitTabPanel.Name = "exitTabPanel";
            this.exitTabPanel.Size = new System.Drawing.Size(250, 50);
            this.exitTabPanel.TabIndex = 65;
            this.exitTabPanel.Click += new System.EventHandler(this.exitLabelText_Click);
            this.exitTabPanel.MouseEnter += new System.EventHandler(this.exitLabelText_MouseEnter);
            this.exitTabPanel.MouseLeave += new System.EventHandler(this.exitLabelText_MouseLeave);
            // 
            // exitLabelText
            // 
            this.exitLabelText.AutoSize = true;
            this.exitLabelText.Font = new System.Drawing.Font("华文琥珀", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.exitLabelText.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.exitLabelText.Location = new System.Drawing.Point(16, 14);
            this.exitLabelText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.exitLabelText.Name = "exitLabelText";
            this.exitLabelText.Size = new System.Drawing.Size(60, 25);
            this.exitLabelText.TabIndex = 6;
            this.exitLabelText.Text = "退出";
            this.exitLabelText.Click += new System.EventHandler(this.exitLabelText_Click);
            this.exitLabelText.MouseEnter += new System.EventHandler(this.exitLabelText_MouseEnter);
            this.exitLabelText.MouseLeave += new System.EventHandler(this.exitLabelText_MouseLeave);
            // 
            // updatepanel
            // 
            this.updatepanel.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.updatepanel.Controls.Add(this.updatelabel);
            this.updatepanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.updatepanel.Location = new System.Drawing.Point(0, 170);
            this.updatepanel.Margin = new System.Windows.Forms.Padding(4);
            this.updatepanel.Name = "updatepanel";
            this.updatepanel.Size = new System.Drawing.Size(250, 50);
            this.updatepanel.TabIndex = 64;
            this.updatepanel.Click += new System.EventHandler(this.updatelabel_Click);
            this.updatepanel.MouseEnter += new System.EventHandler(this.updatelabel_MouseEnter);
            this.updatepanel.MouseLeave += new System.EventHandler(this.updatelabel_MouseLeave);
            // 
            // updatelabel
            // 
            this.updatelabel.AutoSize = true;
            this.updatelabel.Font = new System.Drawing.Font("华文琥珀", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.updatelabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.updatelabel.Location = new System.Drawing.Point(16, 14);
            this.updatelabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.updatelabel.Name = "updatelabel";
            this.updatelabel.Size = new System.Drawing.Size(108, 25);
            this.updatelabel.TabIndex = 6;
            this.updatelabel.Text = "固件更新";
            this.updatelabel.Click += new System.EventHandler(this.updatelabel_Click);
            this.updatelabel.MouseEnter += new System.EventHandler(this.updatelabel_MouseEnter);
            this.updatelabel.MouseLeave += new System.EventHandler(this.updatelabel_MouseLeave);
            // 
            // datapanel
            // 
            this.datapanel.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.datapanel.Controls.Add(this.datapictureBox);
            this.datapanel.Controls.Add(this.datalabel);
            this.datapanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.datapanel.Location = new System.Drawing.Point(0, 120);
            this.datapanel.Margin = new System.Windows.Forms.Padding(4);
            this.datapanel.Name = "datapanel";
            this.datapanel.Size = new System.Drawing.Size(250, 50);
            this.datapanel.TabIndex = 62;
            this.datapanel.Click += new System.EventHandler(this.datalabel_Click);
            this.datapanel.MouseEnter += new System.EventHandler(this.datalabel_MouseEnter);
            this.datapanel.MouseLeave += new System.EventHandler(this.datalabel_MouseLeave);
            // 
            // datapictureBox
            // 
            this.datapictureBox.Image = ((System.Drawing.Image)(resources.GetObject("datapictureBox.Image")));
            this.datapictureBox.Location = new System.Drawing.Point(171, 7);
            this.datapictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.datapictureBox.Name = "datapictureBox";
            this.datapictureBox.Size = new System.Drawing.Size(72, 38);
            this.datapictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.datapictureBox.TabIndex = 7;
            this.datapictureBox.TabStop = false;
            this.datapictureBox.Click += new System.EventHandler(this.datalabel_Click);
            this.datapictureBox.MouseEnter += new System.EventHandler(this.datalabel_MouseEnter);
            this.datapictureBox.MouseLeave += new System.EventHandler(this.datalabel_MouseLeave);
            // 
            // datalabel
            // 
            this.datalabel.AutoSize = true;
            this.datalabel.Font = new System.Drawing.Font("华文琥珀", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.datalabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.datalabel.Location = new System.Drawing.Point(16, 14);
            this.datalabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.datalabel.Name = "datalabel";
            this.datalabel.Size = new System.Drawing.Size(132, 25);
            this.datalabel.TabIndex = 6;
            this.datalabel.Text = "无人机参数";
            this.datalabel.Click += new System.EventHandler(this.datalabel_Click);
            this.datalabel.MouseEnter += new System.EventHandler(this.datalabel_MouseEnter);
            this.datalabel.MouseLeave += new System.EventHandler(this.datalabel_MouseLeave);
            // 
            // connectTabPanel
            // 
            this.connectTabPanel.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.connectTabPanel.Controls.Add(this.connectPicBox);
            this.connectTabPanel.Controls.Add(this.connectLabelText);
            this.connectTabPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.connectTabPanel.Location = new System.Drawing.Point(0, 70);
            this.connectTabPanel.Margin = new System.Windows.Forms.Padding(4);
            this.connectTabPanel.Name = "connectTabPanel";
            this.connectTabPanel.Size = new System.Drawing.Size(250, 50);
            this.connectTabPanel.TabIndex = 1;
            this.connectTabPanel.Click += new System.EventHandler(this.connectTabPanel_Click);
            this.connectTabPanel.MouseEnter += new System.EventHandler(this.connectTabPanel_MouseEnter);
            this.connectTabPanel.MouseLeave += new System.EventHandler(this.connectTabPanel_MouseLeave);
            // 
            // connectPicBox
            // 
            this.connectPicBox.Image = ((System.Drawing.Image)(resources.GetObject("connectPicBox.Image")));
            this.connectPicBox.Location = new System.Drawing.Point(171, 7);
            this.connectPicBox.Margin = new System.Windows.Forms.Padding(4);
            this.connectPicBox.Name = "connectPicBox";
            this.connectPicBox.Size = new System.Drawing.Size(72, 38);
            this.connectPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.connectPicBox.TabIndex = 1;
            this.connectPicBox.TabStop = false;
            this.connectPicBox.Click += new System.EventHandler(this.connectTabPanel_Click);
            this.connectPicBox.MouseEnter += new System.EventHandler(this.connectTabPanel_MouseEnter);
            this.connectPicBox.MouseLeave += new System.EventHandler(this.connectTabPanel_MouseLeave);
            // 
            // connectLabelText
            // 
            this.connectLabelText.AutoSize = true;
            this.connectLabelText.Font = new System.Drawing.Font("华文琥珀", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.connectLabelText.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.connectLabelText.Location = new System.Drawing.Point(16, 14);
            this.connectLabelText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.connectLabelText.Name = "connectLabelText";
            this.connectLabelText.Size = new System.Drawing.Size(132, 25);
            this.connectLabelText.TabIndex = 0;
            this.connectLabelText.Text = "连接单片机";
            this.connectLabelText.Click += new System.EventHandler(this.connectTabPanel_Click);
            this.connectLabelText.MouseEnter += new System.EventHandler(this.connectTabPanel_MouseEnter);
            this.connectLabelText.MouseLeave += new System.EventHandler(this.connectTabPanel_MouseLeave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(250, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(850, 70);
            this.panel1.TabIndex = 64;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(26, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(115, 70);
            this.pictureBox3.TabIndex = 97;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(115, 70);
            this.pictureBox2.TabIndex = 96;
            this.pictureBox2.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tabControl1);
            this.panel5.Location = new System.Drawing.Point(250, 70);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(915, 530);
            this.panel5.TabIndex = 66;
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Right;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(-5, -5);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(885, 540);
            this.tabControl1.TabIndex = 66;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage1.BackgroundImage")));
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.tbMotorVel);
            this.tabPage1.Controls.Add(this.textBox35);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.textBox32);
            this.tabPage1.Controls.Add(this.textBox33);
            this.tabPage1.Controls.Add(this.textBox23);
            this.tabPage1.Controls.Add(this.textBox24);
            this.tabPage1.Controls.Add(this.textBox25);
            this.tabPage1.Controls.Add(this.textBox26);
            this.tabPage1.Controls.Add(this.textBox27);
            this.tabPage1.Controls.Add(this.textBox28);
            this.tabPage1.Controls.Add(this.textBox29);
            this.tabPage1.Controls.Add(this.textBox30);
            this.tabPage1.Controls.Add(this.textBox31);
            this.tabPage1.Controls.Add(this.textBox19);
            this.tabPage1.Controls.Add(this.textBox20);
            this.tabPage1.Controls.Add(this.textBox21);
            this.tabPage1.Controls.Add(this.textBox22);
            this.tabPage1.Controls.Add(this.textBox13);
            this.tabPage1.Controls.Add(this.textBox14);
            this.tabPage1.Controls.Add(this.textBox15);
            this.tabPage1.Controls.Add(this.textBox16);
            this.tabPage1.Controls.Add(this.textBox17);
            this.tabPage1.Controls.Add(this.textBox18);
            this.tabPage1.Controls.Add(this.textBox12);
            this.tabPage1.Controls.Add(this.textBox10);
            this.tabPage1.Controls.Add(this.textBox11);
            this.tabPage1.Controls.Add(this.textBox8);
            this.tabPage1.Controls.Add(this.textBox9);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.textBox7);
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.textBox4);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.btnSetVelocity);
            this.tabPage1.Controls.Add(this.tkMotorVel);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(855, 532);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            // 
            // tbMotorVel
            // 
            this.tbMotorVel.BackColor = System.Drawing.Color.Transparent;
            this.tbMotorVel.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbMotorVel.Location = new System.Drawing.Point(301, 44);
            this.tbMotorVel.Name = "tbMotorVel";
            this.tbMotorVel.Size = new System.Drawing.Size(63, 30);
            this.tbMotorVel.TabIndex = 96;
            this.tbMotorVel.Text = "label16";
            // 
            // textBox35
            // 
            this.textBox35.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox35.Location = new System.Drawing.Point(80, 365);
            this.textBox35.Margin = new System.Windows.Forms.Padding(4);
            this.textBox35.Name = "textBox35";
            this.textBox35.ReadOnly = true;
            this.textBox35.Size = new System.Drawing.Size(113, 25);
            this.textBox35.TabIndex = 95;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(510, 38);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(110, 35);
            this.button4.TabIndex = 94;
            this.button4.Text = "CIRCLE";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(660, 100);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 35);
            this.button3.TabIndex = 93;
            this.button3.Text = "RC";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(510, 100);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 35);
            this.button2.TabIndex = 92;
            this.button2.Text = "GPS";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(360, 100);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 35);
            this.button1.TabIndex = 91;
            this.button1.Text = "IMU";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(5, 365);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 19);
            this.label3.TabIndex = 90;
            this.label3.Text = "CIRCLE:";
            // 
            // textBox32
            // 
            this.textBox32.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox32.Location = new System.Drawing.Point(430, 410);
            this.textBox32.Margin = new System.Windows.Forms.Padding(4);
            this.textBox32.Name = "textBox32";
            this.textBox32.ReadOnly = true;
            this.textBox32.Size = new System.Drawing.Size(52, 25);
            this.textBox32.TabIndex = 89;
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox33.Location = new System.Drawing.Point(500, 410);
            this.textBox33.Margin = new System.Windows.Forms.Padding(4);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(52, 25);
            this.textBox33.TabIndex = 88;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox23.Location = new System.Drawing.Point(220, 365);
            this.textBox23.Margin = new System.Windows.Forms.Padding(4);
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(52, 25);
            this.textBox23.TabIndex = 87;
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox24.Location = new System.Drawing.Point(290, 365);
            this.textBox24.Margin = new System.Windows.Forms.Padding(4);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(52, 25);
            this.textBox24.TabIndex = 86;
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox25.Location = new System.Drawing.Point(360, 365);
            this.textBox25.Margin = new System.Windows.Forms.Padding(4);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(52, 25);
            this.textBox25.TabIndex = 85;
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox26.Location = new System.Drawing.Point(430, 366);
            this.textBox26.Margin = new System.Windows.Forms.Padding(4);
            this.textBox26.Name = "textBox26";
            this.textBox26.ReadOnly = true;
            this.textBox26.Size = new System.Drawing.Size(52, 25);
            this.textBox26.TabIndex = 84;
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox27.Location = new System.Drawing.Point(500, 365);
            this.textBox27.Margin = new System.Windows.Forms.Padding(4);
            this.textBox27.Name = "textBox27";
            this.textBox27.ReadOnly = true;
            this.textBox27.Size = new System.Drawing.Size(52, 25);
            this.textBox27.TabIndex = 83;
            // 
            // textBox28
            // 
            this.textBox28.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox28.Location = new System.Drawing.Point(570, 365);
            this.textBox28.Margin = new System.Windows.Forms.Padding(4);
            this.textBox28.Name = "textBox28";
            this.textBox28.ReadOnly = true;
            this.textBox28.Size = new System.Drawing.Size(52, 25);
            this.textBox28.TabIndex = 82;
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox29.Location = new System.Drawing.Point(220, 410);
            this.textBox29.Margin = new System.Windows.Forms.Padding(4);
            this.textBox29.Name = "textBox29";
            this.textBox29.ReadOnly = true;
            this.textBox29.Size = new System.Drawing.Size(52, 25);
            this.textBox29.TabIndex = 81;
            // 
            // textBox30
            // 
            this.textBox30.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox30.Location = new System.Drawing.Point(290, 410);
            this.textBox30.Margin = new System.Windows.Forms.Padding(4);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(52, 25);
            this.textBox30.TabIndex = 80;
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox31.Location = new System.Drawing.Point(360, 410);
            this.textBox31.Margin = new System.Windows.Forms.Padding(4);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(52, 25);
            this.textBox31.TabIndex = 79;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox19.Location = new System.Drawing.Point(220, 300);
            this.textBox19.Margin = new System.Windows.Forms.Padding(4);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(52, 25);
            this.textBox19.TabIndex = 78;
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox20.Location = new System.Drawing.Point(290, 300);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(52, 25);
            this.textBox20.TabIndex = 77;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox21.Location = new System.Drawing.Point(360, 300);
            this.textBox21.Margin = new System.Windows.Forms.Padding(4);
            this.textBox21.Name = "textBox21";
            this.textBox21.ReadOnly = true;
            this.textBox21.Size = new System.Drawing.Size(52, 25);
            this.textBox21.TabIndex = 76;
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox22.Location = new System.Drawing.Point(430, 301);
            this.textBox22.Margin = new System.Windows.Forms.Padding(4);
            this.textBox22.Name = "textBox22";
            this.textBox22.ReadOnly = true;
            this.textBox22.Size = new System.Drawing.Size(52, 25);
            this.textBox22.TabIndex = 75;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox13.Location = new System.Drawing.Point(220, 235);
            this.textBox13.Margin = new System.Windows.Forms.Padding(4);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(52, 25);
            this.textBox13.TabIndex = 74;
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox14.Location = new System.Drawing.Point(290, 235);
            this.textBox14.Margin = new System.Windows.Forms.Padding(4);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(52, 25);
            this.textBox14.TabIndex = 73;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox15.Location = new System.Drawing.Point(360, 235);
            this.textBox15.Margin = new System.Windows.Forms.Padding(4);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(52, 25);
            this.textBox15.TabIndex = 72;
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox16.Location = new System.Drawing.Point(430, 236);
            this.textBox16.Margin = new System.Windows.Forms.Padding(4);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(52, 25);
            this.textBox16.TabIndex = 71;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox17.Location = new System.Drawing.Point(500, 235);
            this.textBox17.Margin = new System.Windows.Forms.Padding(4);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(52, 25);
            this.textBox17.TabIndex = 70;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox18.Location = new System.Drawing.Point(570, 235);
            this.textBox18.Margin = new System.Windows.Forms.Padding(4);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(52, 25);
            this.textBox18.TabIndex = 69;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox12.Location = new System.Drawing.Point(780, 170);
            this.textBox12.Margin = new System.Windows.Forms.Padding(4);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(52, 25);
            this.textBox12.TabIndex = 68;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox10.Location = new System.Drawing.Point(640, 170);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(52, 25);
            this.textBox10.TabIndex = 67;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox11.Location = new System.Drawing.Point(710, 170);
            this.textBox11.Margin = new System.Windows.Forms.Padding(4);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(52, 25);
            this.textBox11.TabIndex = 66;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox8.Location = new System.Drawing.Point(500, 170);
            this.textBox8.Margin = new System.Windows.Forms.Padding(4);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(52, 25);
            this.textBox8.TabIndex = 65;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox9.Location = new System.Drawing.Point(570, 170);
            this.textBox9.Margin = new System.Windows.Forms.Padding(4);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(52, 25);
            this.textBox9.TabIndex = 64;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox6.Location = new System.Drawing.Point(360, 170);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(52, 25);
            this.textBox6.TabIndex = 63;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox7.Location = new System.Drawing.Point(430, 170);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(52, 25);
            this.textBox7.TabIndex = 62;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox5.Location = new System.Drawing.Point(290, 170);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(52, 25);
            this.textBox5.TabIndex = 61;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox4.Location = new System.Drawing.Point(220, 170);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(52, 25);
            this.textBox4.TabIndex = 60;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(5, 300);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 19);
            this.label2.TabIndex = 59;
            this.label2.Text = "RC:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(5, 235);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 19);
            this.label1.TabIndex = 58;
            this.label1.Text = "GPS:";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label.Location = new System.Drawing.Point(5, 170);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(49, 19);
            this.label.TabIndex = 57;
            this.label.Text = "IMU:";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox3.Location = new System.Drawing.Point(80, 300);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(113, 25);
            this.textBox3.TabIndex = 56;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox2.Location = new System.Drawing.Point(80, 235);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(113, 25);
            this.textBox2.TabIndex = 55;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox1.Location = new System.Drawing.Point(80, 170);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(113, 25);
            this.textBox1.TabIndex = 54;
            // 
            // btnSetVelocity
            // 
            this.btnSetVelocity.BackColor = System.Drawing.Color.Transparent;
            this.btnSetVelocity.FlatAppearance.BorderSize = 0;
            this.btnSetVelocity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSetVelocity.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSetVelocity.Location = new System.Drawing.Point(362, 38);
            this.btnSetVelocity.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetVelocity.Name = "btnSetVelocity";
            this.btnSetVelocity.Size = new System.Drawing.Size(110, 35);
            this.btnSetVelocity.TabIndex = 52;
            this.btnSetVelocity.Text = "设备状态";
            this.btnSetVelocity.UseVisualStyleBackColor = false;
            this.btnSetVelocity.Click += new System.EventHandler(this.btnSetVelocity_Click);
            // 
            // tkMotorVel
            // 
            this.tkMotorVel.AutoSize = false;
            this.tkMotorVel.BackColor = System.Drawing.Color.DarkGray;
            this.tkMotorVel.Location = new System.Drawing.Point(10, 44);
            this.tkMotorVel.Margin = new System.Windows.Forms.Padding(4);
            this.tkMotorVel.Maximum = 10000;
            this.tkMotorVel.Name = "tkMotorVel";
            this.tkMotorVel.Size = new System.Drawing.Size(268, 29);
            this.tkMotorVel.TabIndex = 50;
            this.tkMotorVel.TickStyle = System.Windows.Forms.TickStyle.None;
            this.tkMotorVel.ValueChanged += new System.EventHandler(this.tkMotorVel_ValueChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.textBox43);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.textBox42);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.textBox34);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(855, 532);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(393, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 21);
            this.label5.TabIndex = 62;
            this.label5.Text = "label5";
            // 
            // textBox43
            // 
            this.textBox43.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox43.Location = new System.Drawing.Point(10, 125);
            this.textBox43.Margin = new System.Windows.Forms.Padding(4);
            this.textBox43.Multiline = true;
            this.textBox43.Name = "textBox43";
            this.textBox43.ReadOnly = true;
            this.textBox43.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox43.Size = new System.Drawing.Size(830, 395);
            this.textBox43.TabIndex = 65;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(10, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 21);
            this.label7.TabIndex = 60;
            this.label7.Text = "文件长度：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(10, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 21);
            this.label6.TabIndex = 59;
            this.label6.Text = "选择文件：";
            // 
            // textBox42
            // 
            this.textBox42.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox42.Location = new System.Drawing.Point(130, 20);
            this.textBox42.Margin = new System.Windows.Forms.Padding(4);
            this.textBox42.Name = "textBox42";
            this.textBox42.ReadOnly = true;
            this.textBox42.Size = new System.Drawing.Size(260, 25);
            this.textBox42.TabIndex = 64;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button7.Location = new System.Drawing.Point(710, 20);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(110, 40);
            this.button7.TabIndex = 64;
            this.button7.Text = "开始程序";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox34
            // 
            this.textBox34.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox34.Location = new System.Drawing.Point(130, 75);
            this.textBox34.Margin = new System.Windows.Forms.Padding(4);
            this.textBox34.Name = "textBox34";
            this.textBox34.ReadOnly = true;
            this.textBox34.Size = new System.Drawing.Size(100, 25);
            this.textBox34.TabIndex = 64;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6.Location = new System.Drawing.Point(570, 20);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(110, 40);
            this.button6.TabIndex = 64;
            this.button6.Text = "下载程序";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.Location = new System.Drawing.Point(430, 20);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 40);
            this.button5.TabIndex = 64;
            this.button5.Text = "打开文件";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage3.BackgroundImage")));
            this.tabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.button12);
            this.tabPage3.Controls.Add(this.textBox50);
            this.tabPage3.Controls.Add(this.textBox51);
            this.tabPage3.Controls.Add(this.textBox52);
            this.tabPage3.Controls.Add(this.button13);
            this.tabPage3.Controls.Add(this.textBox53);
            this.tabPage3.Controls.Add(this.textBox54);
            this.tabPage3.Controls.Add(this.textBox55);
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.textBox44);
            this.tabPage3.Controls.Add(this.textBox45);
            this.tabPage3.Controls.Add(this.textBox46);
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(this.textBox47);
            this.tabPage3.Controls.Add(this.textBox48);
            this.tabPage3.Controls.Add(this.textBox49);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.textBox39);
            this.tabPage3.Controls.Add(this.textBox40);
            this.tabPage3.Controls.Add(this.textBox41);
            this.tabPage3.Controls.Add(this.button8);
            this.tabPage3.Controls.Add(this.textBox36);
            this.tabPage3.Controls.Add(this.textBox37);
            this.tabPage3.Controls.Add(this.textBox38);
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(855, 532);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.ForeColor = System.Drawing.Color.DimGray;
            this.label13.Location = new System.Drawing.Point(62, 358);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 21);
            this.label13.TabIndex = 91;
            this.label13.Text = "YawRatePID:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.ForeColor = System.Drawing.Color.DimGray;
            this.label12.Location = new System.Drawing.Point(62, 308);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 21);
            this.label12.TabIndex = 90;
            this.label12.Text = "YawPID:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.ForeColor = System.Drawing.Color.DimGray;
            this.label11.Location = new System.Drawing.Point(62, 260);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 21);
            this.label11.TabIndex = 89;
            this.label11.Text = "RollRatePID:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.ForeColor = System.Drawing.Color.DimGray;
            this.label10.Location = new System.Drawing.Point(62, 208);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 21);
            this.label10.TabIndex = 88;
            this.label10.Text = "RollPID:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(62, 158);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 21);
            this.label9.TabIndex = 87;
            this.label9.Text = "PitchRatePID:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("华文细黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(62, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 21);
            this.label8.TabIndex = 86;
            this.label8.Text = "PitchPID:";
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Transparent;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("华文楷体", 10F);
            this.button12.ForeColor = System.Drawing.Color.Black;
            this.button12.Location = new System.Drawing.Point(421, 355);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(130, 35);
            this.button12.TabIndex = 85;
            this.button12.Text = "YawRatePID";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // textBox50
            // 
            this.textBox50.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox50.Location = new System.Drawing.Point(201, 355);
            this.textBox50.Margin = new System.Windows.Forms.Padding(4);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(52, 25);
            this.textBox50.TabIndex = 84;
            // 
            // textBox51
            // 
            this.textBox51.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox51.Location = new System.Drawing.Point(271, 355);
            this.textBox51.Margin = new System.Windows.Forms.Padding(4);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(52, 25);
            this.textBox51.TabIndex = 83;
            // 
            // textBox52
            // 
            this.textBox52.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox52.Location = new System.Drawing.Point(341, 355);
            this.textBox52.Margin = new System.Windows.Forms.Padding(4);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(52, 25);
            this.textBox52.TabIndex = 82;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Transparent;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("华文楷体", 10F);
            this.button13.ForeColor = System.Drawing.Color.Black;
            this.button13.Location = new System.Drawing.Point(421, 305);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(130, 35);
            this.button13.TabIndex = 81;
            this.button13.Text = "YawPID";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // textBox53
            // 
            this.textBox53.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox53.Location = new System.Drawing.Point(201, 305);
            this.textBox53.Margin = new System.Windows.Forms.Padding(4);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(52, 25);
            this.textBox53.TabIndex = 80;
            // 
            // textBox54
            // 
            this.textBox54.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox54.Location = new System.Drawing.Point(271, 305);
            this.textBox54.Margin = new System.Windows.Forms.Padding(4);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(52, 25);
            this.textBox54.TabIndex = 79;
            // 
            // textBox55
            // 
            this.textBox55.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox55.Location = new System.Drawing.Point(341, 305);
            this.textBox55.Margin = new System.Windows.Forms.Padding(4);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(52, 25);
            this.textBox55.TabIndex = 78;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Transparent;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("华文楷体", 10F);
            this.button10.ForeColor = System.Drawing.Color.Black;
            this.button10.Location = new System.Drawing.Point(421, 255);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(130, 35);
            this.button10.TabIndex = 77;
            this.button10.Text = "RollRatePID";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox44.Location = new System.Drawing.Point(201, 255);
            this.textBox44.Margin = new System.Windows.Forms.Padding(4);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(52, 25);
            this.textBox44.TabIndex = 76;
            // 
            // textBox45
            // 
            this.textBox45.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox45.Location = new System.Drawing.Point(271, 255);
            this.textBox45.Margin = new System.Windows.Forms.Padding(4);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(52, 25);
            this.textBox45.TabIndex = 75;
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox46.Location = new System.Drawing.Point(341, 255);
            this.textBox46.Margin = new System.Windows.Forms.Padding(4);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(52, 25);
            this.textBox46.TabIndex = 74;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Transparent;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("华文楷体", 10F);
            this.button11.ForeColor = System.Drawing.Color.Black;
            this.button11.Location = new System.Drawing.Point(421, 205);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(130, 35);
            this.button11.TabIndex = 73;
            this.button11.Text = "RollPID";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // textBox47
            // 
            this.textBox47.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox47.Location = new System.Drawing.Point(201, 205);
            this.textBox47.Margin = new System.Windows.Forms.Padding(4);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(52, 25);
            this.textBox47.TabIndex = 72;
            // 
            // textBox48
            // 
            this.textBox48.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox48.Location = new System.Drawing.Point(271, 205);
            this.textBox48.Margin = new System.Windows.Forms.Padding(4);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(52, 25);
            this.textBox48.TabIndex = 71;
            // 
            // textBox49
            // 
            this.textBox49.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox49.Location = new System.Drawing.Point(341, 205);
            this.textBox49.Margin = new System.Windows.Forms.Padding(4);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(52, 25);
            this.textBox49.TabIndex = 70;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("华文楷体", 10F);
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(421, 155);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(130, 35);
            this.button9.TabIndex = 69;
            this.button9.Text = "PitchRatePID";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox39.Location = new System.Drawing.Point(201, 155);
            this.textBox39.Margin = new System.Windows.Forms.Padding(4);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(52, 25);
            this.textBox39.TabIndex = 68;
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox40.Location = new System.Drawing.Point(271, 155);
            this.textBox40.Margin = new System.Windows.Forms.Padding(4);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(52, 25);
            this.textBox40.TabIndex = 67;
            // 
            // textBox41
            // 
            this.textBox41.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox41.Location = new System.Drawing.Point(341, 155);
            this.textBox41.Margin = new System.Windows.Forms.Padding(4);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(52, 25);
            this.textBox41.TabIndex = 66;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("华文楷体", 10F);
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.Location = new System.Drawing.Point(421, 105);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(130, 35);
            this.button8.TabIndex = 65;
            this.button8.Text = "PitchPID";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBox36
            // 
            this.textBox36.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox36.Location = new System.Drawing.Point(201, 105);
            this.textBox36.Margin = new System.Windows.Forms.Padding(4);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(52, 25);
            this.textBox36.TabIndex = 62;
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox37.Location = new System.Drawing.Point(271, 105);
            this.textBox37.Margin = new System.Windows.Forms.Padding(4);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(52, 25);
            this.textBox37.TabIndex = 63;
            // 
            // textBox38
            // 
            this.textBox38.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox38.Location = new System.Drawing.Point(341, 105);
            this.textBox38.Margin = new System.Windows.Forms.Padding(4);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(52, 25);
            this.textBox38.TabIndex = 64;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage4.Location = new System.Drawing.Point(4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(855, 532);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage5.Location = new System.Drawing.Point(4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(855, 532);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage6.Location = new System.Drawing.Point(4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(855, 532);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "tabPage6";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1100, 600);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.leftpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "无人机动力单元实验建模系统";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.leftpanel.ResumeLayout(false);
            this.seconddatapanel.ResumeLayout(false);
            this.exitTabPanel.ResumeLayout(false);
            this.exitTabPanel.PerformLayout();
            this.updatepanel.ResumeLayout(false);
            this.updatepanel.PerformLayout();
            this.datapanel.ResumeLayout(false);
            this.datapanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datapictureBox)).EndInit();
            this.connectTabPanel.ResumeLayout(false);
            this.connectTabPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.connectPicBox)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tkMotorVel)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timCheckFrame;
        private System.Windows.Forms.Timer timGetInfo;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel leftpanel;
        private System.Windows.Forms.Panel connectTabPanel;
        private System.Windows.Forms.PictureBox connectPicBox;
        private System.Windows.Forms.Label connectLabelText;
        private System.Windows.Forms.Panel datapanel;
        private System.Windows.Forms.Label datalabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnSetVelocity;
        private System.Windows.Forms.TrackBar tkMotorVel;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel exitTabPanel;
        private System.Windows.Forms.Label exitLabelText;
        private System.Windows.Forms.Panel updatepanel;
        private System.Windows.Forms.Label updatelabel;
        private System.Windows.Forms.PictureBox datapictureBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel seconddatapanel;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label tbMotorVel;
    }
}

